<?php 

class latihan1 extends CI_Controller
{
  public function index(){
    echo "Selamat Datang .. Selamat Belajar Web Programming";
    
  }
}


